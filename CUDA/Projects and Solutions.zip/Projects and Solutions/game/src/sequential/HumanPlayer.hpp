
#include "checkersboard.cpp"

class HumanPlayer
{
    public:
        CheckersBoard makeMove(CheckersBoard, bool) const;
};
