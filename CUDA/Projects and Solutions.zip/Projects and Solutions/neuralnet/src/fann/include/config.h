/* Name of package */
/* #undef PACKAGE */

/* Version number of package */
#define VERSION "2.2.0"

/* Define for the x86_64 CPU famyly */
/* #undef X86_64 */
