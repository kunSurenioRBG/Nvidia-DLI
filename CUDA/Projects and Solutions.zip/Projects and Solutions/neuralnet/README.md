# GPU Teaching Kit: Accelerated Computing
# Feed-Forward Neural Network Demo Project

Galois Field arithmetic for disk failure recovery.

## Building and Running neuralnet

    cd src
    make
    ./nn
