nvcc *.cu -o gf_gpu
