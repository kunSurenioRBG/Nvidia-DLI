# GPU Teaching Kit: Accelerated Computing
# Molecular Dynamics Demo Project

## Galois Field

Galois Field arithmetic for disk failure recovery.

## Building and Running galois

    cd src
    ./make.sh
    ./gf_gpu
