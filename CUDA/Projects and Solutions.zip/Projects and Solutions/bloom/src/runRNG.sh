#/bin/bash

./bin/RNG 0
./bin/RNG 1
./bin/RNG 2
./bin/RNG 3
