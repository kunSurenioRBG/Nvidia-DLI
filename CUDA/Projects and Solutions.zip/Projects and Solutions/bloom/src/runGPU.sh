#/bin/bash

./bin/pbfGPU -k 200 --pbfOutput stats.gpu -t 1 inputs/norm_data.txt inputs/norm_distinct.txt
