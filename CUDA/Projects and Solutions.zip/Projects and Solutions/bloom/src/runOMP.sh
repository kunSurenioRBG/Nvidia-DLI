#/bin/bash

./bin/pbfOMP -k 200 --pbfOutput stats.omp -t 4 inputs/norm_data.txt inputs/norm_distinct.txt
