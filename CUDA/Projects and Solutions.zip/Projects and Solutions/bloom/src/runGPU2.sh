#/bin/bash

./bin/pbfGPU2 -k 200 --pbfOutput stats.gpu2 -t 1 inputs/norm_data.txt inputs/norm_distinct.txt
