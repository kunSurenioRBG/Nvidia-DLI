#/bin/bash

./bin/pbfCPU -k 200 --pbfOutput stats.cpu -t 1 inputs/norm_data.txt inputs/norm_distinct.txt
