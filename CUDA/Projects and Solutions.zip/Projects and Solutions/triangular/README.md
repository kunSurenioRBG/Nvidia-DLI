# GPU Teaching Kit: Accelerated Computing
# Dense Lower Triangular Demo Project

## Dense Lower Triangular Solver

Solver for dense lower triangular systems of equations.

## Building triangular

    cd src
    make
