# GPU Teaching Kit: Accelerated Computing
# PDE Solver Demo Project

## Building and Running pde

Functioning source code was not submitted with this project.
