# GPU Teaching Kit: Accelerated Computing

This is a set of demo projects made by actual teams of students in actual university courses. As a result, the quality of the code and reports is variable.

Not all projects compile properly.

An effort has been made to reorganize each project into a similar directory structure.

## Contents

`project_motivate_rubric.docx`: THis is an example project motivation and rubric.

