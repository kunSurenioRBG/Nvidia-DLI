#ifndef __BRUT_FORC
#define __BRUT_FORC
#include "cpu_md5.h"

#define NUM_LETTERS	26
#define MAX_LETTERS	8

unsigned int brute_force();

#endif
